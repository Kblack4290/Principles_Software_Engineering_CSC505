Module 3 Critical Thinking - Shopping List App Prototype (Keith Black, CSC505)
Resubmitted for the Module 4 Portfolio Milestone

FILES
- shopping_list_prototype.py ................ Python script (run: python shopping_list_prototype.py)
- prototype_image_1.png, prototype_image_2.png  Screenshots of the script running
- shopping_list_component_diagram.pdf / .png  Architecture diagram (UML component diagram), exported
- shopping_list_component_diagram.uxf ....... Editable UMLet source for the diagram
- Shopping List Wireframe.png ............... Paper prototype screens with numbered navigation flow
- Black_Module3_References_APA7.docx ........ Design notes with in-text citations and the APA 7 reference list

ASSUMPTIONS
- Core app: Home, Add Item, View List, Edit/Delete Items, Settings/About (plus View Purchase History).
- Optional extensions (dashed in the diagram): reminders and budget alerts (Notification Service),
  list sharing (List Sharing Service), cloud sync (Cloud Sync Service + Cloud Storage),
  price/budget tracking, and purchase history.
- Sharing is reached from a Share button on the View List screen; it is not drawn on the wireframe
  because it is an optional extension. The Reminders toggle on the Settings screen drives the Notification Service.

HOW TO RUN
1. Open a terminal in this folder.
2. Run: python shopping_list_prototype.py   (or python3, depending on your environment)
